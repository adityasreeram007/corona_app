import requests
import csv
url='https://pomber.github.io/covid19/timeseries.json'
data=requests.get(url)
jdata=data.json()
data=jdata['India']
head=['date','confirmed','death','recovered']
listx=[]
for j in data:
    x=[]
    for i in j:
        x.append(j[i])
    listx.append(x)
with open('dailydataind.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in listx:
        writer.writerow(j)
