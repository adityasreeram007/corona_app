import requests
import csv
url="https://pomber.github.io/covid19/timeseries.json"
data=requests.get(url)
jdata=data.json()
