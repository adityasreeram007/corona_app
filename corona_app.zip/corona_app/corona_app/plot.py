import pandas as pd 
data=pd.read_csv('covidindiascrap.csv')
print(data)
import matplotlib.pyplot as plt
state=list(data['STATE'])[::-1]
total=list(data['CONFIRMED'])[::-1]

d=plt.figure(figsize=(20,20))
d.suptitle('Indian States')

plt.barh(state,total,align='center' ,alpha=0.5,color='blue',edgecolor="black")
plt.savefig('images/indstates.jpg')
plt.show()
