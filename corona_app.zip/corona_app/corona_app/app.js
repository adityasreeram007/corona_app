var ex=require('express');

var csv=require('csv')

var app=ex();

var bodyParser = require('body-parser');
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine','ejs')
app.listen(3000);

var fs = require('fs'); 
var parse = require('csv-parse');

const spawn=require('child_process').spawn
var c=spawn('python3',['world.py'])
c.stdout.on('data', function(data) {

    console.log(data.toString());
   
});
app.get('/',function(req,res){
    res.render('mainpage');
});
var c=spawn('python3',['covidindscrap.py'])
c.stdout.on('data', function(data) {

    console.log(data.toString());
   
});

var csvData=[];

fs.createReadStream('/home/aditya/Documents/corona_app/worldcases.csv')
    .pipe(parse({delimiter: ','}))
    .on('data', function(csvrow) {
       
        csvData.push(csvrow);        
    })
    .on('end',function() {
        
          fs.close;
    });    

var totalworlddata=[]
fs.createReadStream('/home/aditya/Documents/corona_app/totalworld.csv')
    .pipe(parse({delimiter: ','}))
    .on('data', function(csvrow) {
       
        totalworlddata.push(csvrow);        
    })
    .on('end',function() {
        
          fs.close;
    });  
var totalindia=[]
fs.createReadStream('/home/aditya/Documents/corona_app/totalindia.csv')
    .pipe(parse({delimiter: ','}))
    .on('data', function(csvrow) {
       
        totalindia.push(csvrow);        
    })
    .on('end',function() {
        
          fs.close;
    });  

app.get('/world',function(req,res){
res.render('world',{result:csvData});
});

// app.post('/firstpage',function(req,res){
//     var uname=req.body.username;
//     var pass=req.body.password;
    
//     var passer='';
//         var curser=db.collection('mobologin').find({});
//         curser.each(function(er,result)
//         {   
//            if (result!=null){
//             if (result.usename.localeCompare(uname)==0 && result.password.localeCompare(pass)==0 ){
                
                
//                 res.render('firstpage',{result:csvData});
               
                
                
//             }}
//             else{
//                 res.render('login');
//             }
//     });
// });
// app.post('/india',fucntion(req,res){

// });

    var indData=[];
    fs.createReadStream('/home/aditya/Documents/corona_app/covidindiascrap.csv')
.pipe(parse({delimiter: ','}))
.on('data', function(csvrow) {
   
    indData.push(csvrow);        
})
.on('end',function() {
  
});  
app.get('/india',function (req,res) {

   
    res.render('india',{result:indData,totaldata:totalindia});
});