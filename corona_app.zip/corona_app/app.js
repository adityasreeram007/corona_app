var ex=require('express');
var app=ex();
var bodyParser = require('body-parser');
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine','ejs')
app.listen(3000);
app.get('/',function(req,res){
  
    res.render('login');
});


app.post('/firstpage',function(req,res){
    console.log(req.body.username)

    res.render('firstpage');

});