var ex=require('express');
const mongo=require('mongoose');
mongo.connect("mongodb://localhost:27017/flaskdb")
var db=mongo.connection;
var app=ex();
var bodyParser = require('body-parser');
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine','ejs')
app.listen(3000);
app.get('/',function(req,res){
  
    res.render('login');
});


app.post('/firstpage',function(req,res){
    var uname=req.body.username;
    var pass=req.body.password;
    var passer='';
        var curser=db.collection('mobologin').find({});
        curser.each(function(er,result)
        {   //if er throw err;
            console.log(result);
            console.log(typeof result);
           if (result!=null){
            if (result.usename.localeCompare(uname)==0 && result.password.localeCompare(pass)==0 ){
    
                res.render('firstpage');
                
            }}
            else{
                res.render('login');
            }
            
            
            
        });
        
   

});