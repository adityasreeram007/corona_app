import requests
import csv
import pandas as pd
import matplotlib.pyplot as plt
url='https://pomber.github.io/covid19/timeseries.json'
data=requests.get(url)
jdata=data.json()
data=jdata['India']
head=['date','confirmed','death','recovered']
listx=[]
for j in data:
    x=[]
    for i in j:
        x.append(j[i])
    listx.append(x)
with open('dailydataind.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in listx:
        writer.writerow(j)
data=pd.read_csv('dailydataind.csv')
date=list(data['date'])
confirm=list(data['confirmed'])
for i in range(len(date)):
    c=date.pop(0)
    if len(c)==8:
        c=c[-3:]
        date.append(c)
    else:
        c=c[-4:]
        date.append(c)
plt.figure(figsize=(12,12))
plt.plot(date[-10:],confirm[-10:],color="red")
plt.savefig('images/indhis.jpg')
# plt.show()
    