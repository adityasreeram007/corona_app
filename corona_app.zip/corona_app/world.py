import requests
import csv
url="https://coronavirus-19-api.herokuapp.com/countries"
url1="https://coronavirus-19-api.herokuapp.com/all"
r=requests.get(url)
r1=requests.get(url1)
jdata=r.json()
jdata1=r1.json()
head=['COUNTRY','CASES','NEW CASES','DEATHS','NEW DEATHS','RECOVERED','ACTIVE CASES','CRIRTICAL CASES','CASES/MILLION','DEATH/MILLION','FIRSTCASE']
#print(jdata)
regionlist=[]
for j in jdata:
    ls=[]
    for x in j:
        if x=='firstCase':
            ls.append(j[x][1:])
        else:
            ls.append(j[x])
    regionlist.append(ls)
#print(regionlist)
regionlist.sort(key=lambda x:x[1],reverse=True)
with open('worldcases.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in regionlist:
        writer.writerow(j)
head1=['CONFIRMED','DEATH','RECOVERED']
row=[]
for k in jdata1:
    row.append(jdata1[k])

with open('totalworld.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head1)
    writer.writerow(row)
    
    #writer.writerow(cont)
print(jdata1)    