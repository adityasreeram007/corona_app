import requests
import csv
url="https://coronavirus-19-api.herokuapp.com/countries"
r=requests.get(url)
jdata=r.json()
head=['country','cases','today','deaths','todaydeath','recovered','active','critical','casespermillion','deathpermillion']
print(jdata)
regionlist=[]
for j in jdata:
    ls=[]
    for x in j:
        ls.append(j[x])
    regionlist.append(ls)
with open('worldcases.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in regionlist:
        writer.writerow(j)
    