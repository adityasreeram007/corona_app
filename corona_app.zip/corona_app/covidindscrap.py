import requests
import csv
url="https://api.rootnet.in/covid19-in/stats/latest"
r=requests.get(url)
jdata=r.json()
total=jdata['data']['summary']
totallist=[]
head=['state','confirin','confirfor','dis','death']
for j in total:
    totallist.append(total[j])
region=jdata['data']['regional']
regionlist=[]
for j in region:
    ls=[]
    for x in j:
        ls.append(j[x])
    regionlist.append(ls)
with open('covidindiascrap.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in regionlist:
        writer.writerow(j)
    writer.writerow(totallist)
        
# print(soup)

