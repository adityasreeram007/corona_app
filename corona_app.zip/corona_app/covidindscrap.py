import requests
import csv
url="https://api.rootnet.in/covid19-in/unofficial/covid19india.org/statewise"
r=requests.get(url)
jdata=r.json()
print(jdata)
total=jdata['data']['total']
totallist=[]
headtot=['CONFIRMED','RECOVERED','DEATH','ACTIVE']
head=['STATE','CONFIRMED','RECOVERED','DEATH','ACTIVE']
for j in total:
    totallist.append(total[j])
region=jdata['data']['statewise']

regionlist=[]
for j in region:
    ls=[]
    for x in j:
        ls.append(j[x])
    regionlist.append(ls)

regionlist.sort(key=lambda x:x[1],reverse=True)
with open('covidindiascrap.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in regionlist:
        writer.writerow(j)
with open('totalindia.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(headtot)
    writer.writerow(totallist)
        
# print(soup)

