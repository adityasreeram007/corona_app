import requests
import csv
url="https://api.rootnet.in/covid19-in/stats/latest"
r=requests.get(url)
jdata=r.json()
print(jdata)
total=jdata['data']['summary']
totallist=[]
headtot=['TOTAL','CONFIRMED INDIAN','CONFIRMED FORIEGN','DISCHARGED','DEATH','locnotidentitifed']
head=['STATE','CONFIRMED INDIAN','DISCHARGED','DEATH','CONFIRMED FORIEGN']
for j in total:
    totallist.append(total[j])
region=jdata['data']['regional']
regionlist=[]
for j in region:
    ls=[]
    for x in j:
        ls.append(j[x])
    regionlist.append(ls)
regionlist.sort(key=lambda x:x[1],reverse=True)
with open('covidindiascrap.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(head)
    for j in regionlist:
        writer.writerow(j)
with open('totalindia.csv','w',newline='') as file:
    writer=csv.writer(file)
    writer.writerow(headtot)
    writer.writerow(totallist)
        
# print(soup)

